// Part 2: Handle Unknown Function Arguments
function unknownArgs(...args) {
    // Your code here
}
