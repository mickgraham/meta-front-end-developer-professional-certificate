// Task 1: Code the timesTwo function declaration
// WRITE YOUR CODE HERE - Create a function named timesTwo that takes a number and returns the value multiplied by 2

// Task 2: Export the timesTwo function as a module
// WRITE YOUR CODE HERE - Use module.exports to export the timesTwo function
