const timesTwo = require('./timesTwo');

// Write the first test
// WRITE YOUR CODE HERE - Use the test() function to write a test for timesTwo with the description "returns the number times 2"
// WRITE YOUR CODE HERE - Use expect() and toBe() to verify timesTwo(10) equals 20
