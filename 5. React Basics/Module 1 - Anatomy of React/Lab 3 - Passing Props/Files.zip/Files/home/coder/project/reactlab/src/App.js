import Heading from "./Heading";

function App() {
    return (
        <div className="App">
            <Heading firstName='Mick'/>
            <Heading firstName='Mick2'/>
        </div>
    );
};

export default App;
